/**
  * @file chassis_task.h
  * @version 1.0
  * @date Oct,19th 2018
  *
  * @brief  
  *
  *	@author lin kr
  *
  */
#ifndef __CLASSIS_TASK_H__
#define __CLASSIS_TASK_H__
#ifdef  __CHASSIS_TASK_GLOBALS
#define __CHASSIS_TASK_EXT
#else
#define __CHASSIS_TASK_EXT extern
#endif

#include "stm32f4xx_hal.h"

#define CHASSIS_PERIOD 10
#define MAX_WHEEL_RPM   9000		//���̵��ת�����Ƽ���

/* chassis parameter structure */
typedef enum
{
  CHASSIS_STOP   ,
  CHASSIS_REMOTE_NORMAL ,
	CHASSIS_REMOTE_SLOW		,
	CHASSIS_RC_NEAR		,
	
  CHASSIS_KB_NEAR   ,//��ǽ�Զ�ģʽ
	CHASSIS_KB_LIMIT_TOUCH	,
	

  CHASSIS_KB  ,
} chassis_mode_e;

typedef enum
{
	NEAR_AIMING		,
	NEAR_DONE			,
  LEFT_AIMING   ,
  LEFT_DONE 		,
  RIGHT_AIMING  ,//��ǽ�Զ�ģʽ
	RIGHT_AIMIGN	,
  NO_AIMING  ,
} chassis_aim_mode_e;
typedef struct
{
  float           vx; // forward/back
  float           vy; // left/right
  float           vw; // rotate
	
	int LIMIT_LEFT;
	int LIMIT_RIGHT;
	
  chassis_mode_e  ctrl_mode;
  int16_t         current[4];
	chassis_aim_mode_e aim_ctrl_mode;
  int16_t         wheel_spd_fdb[4];//����ֵ
  int16_t         wheel_spd_ref[4];//Ŀ��ֵ

  int16_t         position_ref;
	float 					position_error;
	float 					dis_ref;
	
  float           target_vx; // forward/back
  float           target_vy; // left/right
  float           target_vw; // rotate

} chassis_t;

__CHASSIS_TASK_EXT chassis_t chassis;

void chassis_task(void const *argu);
void chassis_init(void);
void mecanum_calc(float vx, float vy, float vw, int16_t speed[]);

#endif
